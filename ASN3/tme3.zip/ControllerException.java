public class ControllerException extends Exception {
    public ControllerException(String errorMessage) {
        super(errorMessage);
    }
}