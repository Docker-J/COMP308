public enum Note {
    MIDDLE_C, C_SHARP, B_FLAT;
}
